#!/bin/bash

echo "on" > /proc/acpi/ibm/light
