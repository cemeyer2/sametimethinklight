#!/bin/bash

echo "off" > /proc/acpi/ibm/light
