package com.ibm.lnja.sametimethinklight.preferences;

import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.ibm.lnja.sametimethinklight.activator.SametimeThinklightPlugin;
import com.ibm.lnja.sametimethinklight.message.ChatMessageHandler;

/**
 * Preference page for adding, removing, and editing
 * quick responses.
 */

public class SametimeThinklightPreferencesPage extends PreferencePage implements
		IWorkbenchPreferencePage {
	private Text imTextSpeed;
	private Text imTextCount;
	private Text fileSpeed;
	private Text fileCount;
	private Button enableAll, enableIMText, enableFile;
	
	private Composite cmpParent;

	/**
	 * Create the preference page.
	 */
	public SametimeThinklightPreferencesPage() {
	}

	/**
	 * Create contents of the preference page.
	 * @param parent
	 */
	@Override
	public Control createContents(Composite parent) {
		cmpParent = parent;
		Composite container = new Composite(parent, SWT.NULL);
		
		enableAll = new Button(container, SWT.CHECK);
		enableAll.setBounds(10, 23, 160, 24);
		enableAll.setText("Enable ThinkLight");
		enableAll.setSelection(getBool(SametimeThinklightPlugin.GLOBAL_ENABLED));
		enableAll.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				toggleAll();
			}
		});
		
		enableIMText = new Button(container, SWT.CHECK);
		enableIMText.setBounds(10, 61, 160, 24);
		enableIMText.setText("On Message Receive");
		enableIMText.setSelection(getBool(SametimeThinklightPlugin.IM_TEXT_ENABLED));
		enableIMText.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				imTextCount.setEnabled(enableIMText.getSelection());
				imTextSpeed.setEnabled(enableIMText.getSelection());
			}
		});
		
		Label lblNewLabel = new Label(container, SWT.NONE);
		lblNewLabel.setBounds(10, 91, 87, 17);
		lblNewLabel.setText("Blink Count");
		
		Label lblNewLabel_1 = new Label(container, SWT.NONE);
		lblNewLabel_1.setBounds(10, 125, 87, 17);
		lblNewLabel_1.setText("Blink Speed");
		
		imTextSpeed = new Text(container, SWT.BORDER);
		imTextSpeed.setBounds(95, 125, 75, 27);
		imTextSpeed.setText(String.valueOf(getInt(SametimeThinklightPlugin.IM_TEXT_SPEED)));
		imTextSpeed.setEnabled(getBool(SametimeThinklightPlugin.IM_TEXT_ENABLED));
		
		imTextCount = new Text(container, SWT.BORDER);
		imTextCount.setBounds(95, 91, 75, 27);
		imTextCount.setText(String.valueOf(getInt(SametimeThinklightPlugin.IM_TEXT_COUNT)));
		imTextCount.setEnabled(getBool(SametimeThinklightPlugin.IM_TEXT_ENABLED));
		
		fileSpeed = new Text(container, SWT.BORDER);
		fileSpeed.setBounds(95, 236, 75, 27);
		fileSpeed.setText(String.valueOf(getInt(SametimeThinklightPlugin.FILE_SPEED)));
		fileSpeed.setEnabled(getBool(SametimeThinklightPlugin.FILE_ENABLED));
		
		fileCount = new Text(container, SWT.BORDER);
		fileCount.setBounds(95, 202, 75, 27);
		fileCount.setText(String.valueOf(getInt(SametimeThinklightPlugin.FILE_COUNT)));
		fileCount.setEnabled(getBool(SametimeThinklightPlugin.FILE_ENABLED));
		
		Label label = new Label(container, SWT.NONE);
		label.setText("Blink Speed");
		label.setBounds(10, 236, 87, 17);
		
		Label label_1 = new Label(container, SWT.NONE);
		label_1.setText("Blink Count");
		label_1.setBounds(10, 202, 87, 17);
		
		enableFile = new Button(container, SWT.CHECK);
		enableFile.setText("On File Receive");
		enableFile.setBounds(10, 172, 160, 24);
		enableFile.setSelection(getBool(SametimeThinklightPlugin.FILE_ENABLED));
		enableFile.addSelectionListener(new SelectionAdapter(){
			@Override
			public void widgetSelected(SelectionEvent arg0) {
				fileCount.setEnabled(enableFile.getSelection());
				fileSpeed.setEnabled(enableFile.getSelection());
			}
		});
		

		
		Button testButton = new Button(container, SWT.NONE);
		testButton.setBounds(10, 300, 160, 29);
		testButton.setText("Test ThinkLight");
		testButton.addSelectionListener(new SelectionAdapter(){

			@Override
			public void widgetSelected(SelectionEvent arg0) {
				ChatMessageHandler.testBlink();
			}
		});
		toggleAll();
		return container;
	}

	/**
	 * Initialize the preference page.
	 */
	public void init(IWorkbench workbench) {
		noDefaultAndApplyButton();
	}
	
	private boolean getBool(String key){
		int val = SametimeThinklightPlugin.getDefault().get(key);
		if(val > 0){
			return true;
		} else {
			return false;
		}
	}
	
	private int getInt(String key){
		return SametimeThinklightPlugin.getDefault().get(key);
	}
	
	private int getInt(Button button){
		if(button.getSelection()){
			return 1;
		}
		return 0;
	}
	
	private int getInt(Text box){
		return Integer.parseInt(box.getText());
	}
	
	private void toggleAll(){
		if(enableAll.getSelection()){
			enableIMText.setEnabled(true);
			enableFile.setEnabled(true);
			
			if(enableIMText.getSelection()){
				imTextCount.setEnabled(true);
				imTextSpeed.setEnabled(true);
			}
			
			if(enableFile.getSelection()){
				fileCount.setEnabled(true);
				fileSpeed.setEnabled(true);
			}
		} else {
			enableIMText.setEnabled(false);
			enableFile.setEnabled(false);
			imTextCount.setEnabled(false);
			imTextSpeed.setEnabled(false);
			fileCount.setEnabled(false);
			fileSpeed.setEnabled(false);
		}
	}
	
	private boolean checkInt(Text box){
		String value = box.getText();
		try{
			Integer.parseInt(value);
			return true;
		} catch(NumberFormatException nfe){
			MessageDialog.openError(cmpParent.getShell(), "Error", "All values in text boxes must be integers");
			return false;
		}
	}

    public boolean performOk() {
    	boolean saved = saveResponses();
    	if(!saved){
        	SametimeThinklightPlugin.getDefault().debug("error saving preferences");
    	}
    	return saved;
    }

    public boolean performCancel() {
    	SametimeThinklightPlugin.getDefault().debug("Preferences canceled");
        return true;
    }

    private boolean saveResponses() {
    	SametimeThinklightPlugin.getDefault().debug("Saving preferences");
    	if(!checkInt(imTextCount)){
    		return false;
    	}
    	if(!checkInt(imTextSpeed)){
    		return false;
    	}
    	if(!checkInt(fileCount)){
    		return false;
    	}
    	if(!checkInt(fileSpeed)){
    		return false;
    	}
    	SametimeThinklightPlugin.getDefault().set(SametimeThinklightPlugin.GLOBAL_ENABLED, getInt(enableAll));
    	SametimeThinklightPlugin.getDefault().set(SametimeThinklightPlugin.IM_TEXT_ENABLED, getInt(enableIMText));
    	SametimeThinklightPlugin.getDefault().set(SametimeThinklightPlugin.FILE_ENABLED, getInt(enableFile));
    	SametimeThinklightPlugin.getDefault().set(SametimeThinklightPlugin.IM_TEXT_SPEED, getInt(imTextSpeed));
    	SametimeThinklightPlugin.getDefault().set(SametimeThinklightPlugin.IM_TEXT_COUNT, getInt(imTextCount));
    	SametimeThinklightPlugin.getDefault().set(SametimeThinklightPlugin.FILE_SPEED, getInt(fileSpeed));
    	SametimeThinklightPlugin.getDefault().set(SametimeThinklightPlugin.FILE_COUNT, getInt(fileCount));
    	SametimeThinklightPlugin.getDefault().writeProperties();
    	SametimeThinklightPlugin.getDefault().debug("Preferences saved");
    	return true;
    }
}
