package com.ibm.lnja.sametimethinklight.message;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.net.URL;

import org.eclipse.core.runtime.FileLocator;

import com.ibm.collaboration.realtime.messages.DefaultMessageHandler;
import com.ibm.collaboration.realtime.messages.FileReceivedMessage;
import com.ibm.collaboration.realtime.messages.Message;
import com.ibm.collaboration.realtime.messages.im.ImTextReceivedMessage;
import com.ibm.collaboration.realtime.messages.im.ManyToManyTextReceivedMessage;
import com.ibm.lnja.sametimethinklight.activator.SametimeThinklightPlugin;
import com.ibm.lnja.sametimethinklight.activator.SametimeThinklightPlugin.OperatingSystem;

/**
 * Handler that actually does the blinking of the ThinkLight
 * @author Charlie Meyer <cemeyer@us.ibm.com>
 * @version 2012.08.29
 */
public class ChatMessageHandler extends DefaultMessageHandler {

	private static String windowsPath, linuxOnPath, linuxOffPath;
	
	public ChatMessageHandler(){
		SametimeThinklightPlugin.getDefault().debug("Handler Created");
		windowsPath = getPath("/resources/ThinkLight.exe");
		linuxOnPath = getPath("/resources/ThinklightOn.sh");
		linuxOffPath = getPath("/resources/ThinklightOff.sh");
		if(SametimeThinklightPlugin.OS == OperatingSystem.LINUX){
			runCommand("chmod +x "+linuxOnPath);
			runCommand("chmod +x "+linuxOffPath);
		}
	}
	
	private String getPath(String resourceName){
		String path = "";
		try{
			URL bundleRoot = SametimeThinklightPlugin.getDefault().getBundle().getEntry(resourceName);  
			URL fileURL = FileLocator.toFileURL(bundleRoot);  
			File file = new File(fileURL.toURI());  
			SametimeThinklightPlugin.getDefault().debug(resourceName+" exists?: "+file.exists());
			path = file.getCanonicalPath();
			SametimeThinklightPlugin.getDefault().debug("path: "+path);
		} catch(IOException ioe){
			ioe.printStackTrace();
			SametimeThinklightPlugin.getDefault().debug(ioe);
			return null;
		} catch (URISyntaxException e) {
			SametimeThinklightPlugin.getDefault().debug(e);
			return null;
		}
		return path;
	}

	private static synchronized void blink(final int count, final int speed, String from, String text, boolean isFile){		
		SametimeThinklightPlugin.getDefault().debug("Blinking for "+count+" flashes at "+speed+" flashes per second");
		if(SametimeThinklightPlugin.OS == OperatingSystem.WINDOWS){
			blinkWindows(count, speed);
		} else if(SametimeThinklightPlugin.OS == OperatingSystem.LINUX){
			blinkLinux(count, speed);
		} else {
			SametimeThinklightPlugin.getDefault().debug("Unsupported OS, cannot blink");
		}
	}
	
	private static void blinkWindows(final int count, final int speed){
		Thread th = new Thread(new Runnable(){
			public void run(){
				String command = windowsPath+" blink "+count+" "+speed;
				runCommand(command);
			}
		});
		th.start();
	}
	
	private static void blinkLinux(final int count, final int speed){
		Thread th = new Thread(new Runnable(){
			public void run(){
				long delay = (long)(1000d/(speed*2d));
				for(int i = 0; i < count; i++){
					toggleLinux(true);
					try {
						Thread.sleep(delay);
					} catch (InterruptedException e) {
						SametimeThinklightPlugin.getDefault().debug(e);
					}
					toggleLinux(false);
					try {
						Thread.sleep(delay);
					} catch (InterruptedException e) {
						SametimeThinklightPlugin.getDefault().debug(e);
					}
				}
			}
		});
		th.start();
	}
	
	private static void toggleLinux(boolean on){
		String command = linuxOffPath;
		if(on){
			command = linuxOnPath;
		}
		runCommand(command);	
	}

	private static void runCommand(String command) {
		try{
			SametimeThinklightPlugin.getDefault().debug("executing: "+command);
			Process p = Runtime.getRuntime().exec(command);
			BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String line = "";
			while((line = in.readLine()) != null){
				SametimeThinklightPlugin.getDefault().debug(line);
			}
			in.close();
			in = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			while((line = in.readLine()) != null){
				SametimeThinklightPlugin.getDefault().debug(line);
			}
			in.close();
			p.waitFor();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SametimeThinklightPlugin.getDefault().debug(e);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			SametimeThinklightPlugin.getDefault().debug(e);
		}
	}

	public void handleMessage(FileReceivedMessage arg0) {
		SametimeThinklightPlugin.getDefault().debug("FileReceivedMessage");
		int enabled = SametimeThinklightPlugin.getDefault().get(SametimeThinklightPlugin.FILE_ENABLED);
		if(enabled > 0){
			int count = SametimeThinklightPlugin.getDefault().get(SametimeThinklightPlugin.FILE_COUNT);
			int speed = SametimeThinklightPlugin.getDefault().get(SametimeThinklightPlugin.FILE_SPEED);
			blink(count, speed, arg0.getPartnerAlias(), "File "+arg0.getFileName()+" has been received", true);
		}
		super.handleMessage(arg0);
	}

	public void handleMessage(ImTextReceivedMessage arg0) {
		SametimeThinklightPlugin.getDefault().debug("ImTextReceivedMessage");
		int enabled = SametimeThinklightPlugin.getDefault().get(SametimeThinklightPlugin.IM_TEXT_ENABLED);
		if(enabled > 0){
			int count = SametimeThinklightPlugin.getDefault().get(SametimeThinklightPlugin.IM_TEXT_COUNT);
			int speed = SametimeThinklightPlugin.getDefault().get(SametimeThinklightPlugin.IM_TEXT_SPEED);
			blink(count, speed, arg0.getPartnerDisplayName(), arg0.getText(), false);
		}
		super.handleMessage(arg0);
	}

	public void handleMessage(ManyToManyTextReceivedMessage arg0) {
		SametimeThinklightPlugin.getDefault().debug("ManyToManyTextReceivedMessage");
		int enabled = SametimeThinklightPlugin.getDefault().get(SametimeThinklightPlugin.IM_TEXT_ENABLED);
		if(enabled > 0){
			int count = SametimeThinklightPlugin.getDefault().get(SametimeThinklightPlugin.IM_TEXT_COUNT);
			int speed = SametimeThinklightPlugin.getDefault().get(SametimeThinklightPlugin.IM_TEXT_SPEED);
			blink(count, speed, arg0.getPartnerDisplayName(), arg0.getText(), false);
		}
		super.handleMessage(arg0);
	}

	@Override
	public void handleDefaultMessage(Message arg0) {
		//dont do anything special
	}

	public static void testBlink(){
		blink(4, 3, "test", "Hello, World!", false);
	}
}
