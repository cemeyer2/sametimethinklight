package com.ibm.lnja.sametimenotifications.message.notification;

/*
 * Licensed Materials - Property of IBM
 *
 * L-KBIM-82KJL8
 *
 * (C) Copyright IBM Corp. 2006, 2010. All rights reserved.
 *
 * US Government Users Restricted Rights- Use, duplication or
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 */


import org.eclipse.swt.graphics.Image;

import com.ibm.collaboration.realtime.messages.AlertUserActionMessage;
import com.ibm.collaboration.realtime.messages.AlertUserMessage;
import com.ibm.collaboration.realtime.ui.alert.AlertFactory;
import com.ibm.collaboration.realtime.ui.alert.AlertOptions;

/**
 * This class demonstrates how to generate and process a basic pop-up alert.
 */
public class BasicAlert
{
    private BasicAlert() {
    }

    public static void createAlert(String title, String text, Image image) {
        AlertOptions options = AlertFactory.createAlertOptions();
        options.setTitle(title);
        options.setMessage(text.replaceAll("\\<.*?\\>", ""));
        options.setMessageImage(image);
        AlertUserMessage alertMessage = new AlertUserMessage();
        alertMessage.setAlertOptions(options);
        alertMessage.post();
    }

    public static void handleMessage(AlertUserActionMessage message) {

    }
}
