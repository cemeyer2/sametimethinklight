package com.ibm.lnja.sametimenotifications.message;

import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;

import com.ibm.collaboration.realtime.contacts.search.DirectoryInfo;
import com.ibm.collaboration.realtime.messages.DefaultMessageHandler;
import com.ibm.collaboration.realtime.messages.FileReceivedMessage;
import com.ibm.collaboration.realtime.messages.Message;
import com.ibm.collaboration.realtime.messages.im.ImTextReceivedMessage;
import com.ibm.collaboration.realtime.messages.im.ManyToManyTextReceivedMessage;
import com.ibm.collaboration.realtime.people.PeopleUtil;
import com.ibm.collaboration.realtime.people.Person;
import com.ibm.lnja.sametimenotifications.activator.SametimeNotificationsPlugin;
import com.ibm.lnja.sametimenotifications.message.notification.BasicAlert;
import com.lotus.sametime.core.comparch.STSession;

/**
 * Handler that actually does the notifications
 * @author Charlie Meyer <cemeyer@us.ibm.com>
 * @version 2012.10.09
 */
public class ChatMessageHandler extends DefaultMessageHandler {

	
	private static STSession session = null; 
    private static Person me = null;

	public ChatMessageHandler(){
		SametimeNotificationsPlugin.getDefault().debug("Handler Created");

		
		
		
	}
	

	private static synchronized void notify(final Person from, final String text, final boolean isFile){
//		SametimeNotificationsPlugin.getDefault().debug(text);
//		if(queue == null){
//			SametimeNotificationsPlugin.getDefault().debug("initializing message queue");
//			queue = new NotificationQueue();
//		}
//		Thread th = new Thread(new Runnable(){
//			public void run(){
//				if(SametimeNotificationsPlugin.getDefault().get(SametimeNotificationsPlugin.NOTIFICATIONS_ENABLED) > 0){
//					SametimeNotificationsPlugin.getDefault().debug("initializing message");
//					String fileReceived = "File received from";
//					String messageReceived = "New message from";
//					String title = "<html><b>"+((isFile)?fileReceived:messageReceived)+" "+from+"</b></html>";
//					String text2 = text.replace("\n", "<br>");
//					SametimeNotificationFrame frame = new SametimeNotificationFrame(title, "<html>"+text2+"</html>");
//					frame.pack();
//					Notification note = new Notification(frame, WindowPosition.BOTTOMRIGHT, 25, 25, SametimeNotificationsPlugin.getDefault().get(SametimeNotificationsPlugin.NOTIFICATIONS_SPEED));
//					SametimeNotificationsPlugin.getDefault().debug("adding message to queue");
//					queue.add(note);
//				}
//			}
//		});
//		th.start();
		
		String sfrom = from.getDisplayName();
		DirectoryInfo info = from.getDirectoryInfo();
		Image image = new Image(Display.getDefault(), info.get(DirectoryInfo.IMAGE_PATH).toString() );
		
		BasicAlert.createAlert(sfrom, text, image);
		
	}
	
	

	public void handleMessage(FileReceivedMessage arg0) {
		super.handleMessage(arg0);
	}

	public void handleMessage(ImTextReceivedMessage arg0) {
		SametimeNotificationsPlugin.getDefault().debug("ImTextReceivedMessage");
		notify(PeopleUtil.getPersonById(arg0.getPartnerUniqueId()), arg0.getText(), false);
		super.handleMessage(arg0);
	}

	public void handleMessage(ManyToManyTextReceivedMessage arg0) {
		SametimeNotificationsPlugin.getDefault().debug("ManyToManyTextReceivedMessage");
		notify(PeopleUtil.getPersonById(arg0.getPartnerUniqueId()), arg0.getText(), false);
		super.handleMessage(arg0);
	}

	@Override
	public void handleDefaultMessage(Message arg0) {
		//dont do anything special
	}

	public static void testNotification(){
		if(me == null){
			me = PeopleUtil.getLocalPerson(); 
		}
		notify(me, "Hello, World!", false);
	}
}
