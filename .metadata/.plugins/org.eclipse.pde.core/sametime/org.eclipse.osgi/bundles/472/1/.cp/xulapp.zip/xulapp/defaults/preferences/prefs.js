pref("toolkit.defaultChromeURI", "chrome://xulapp/content/main.xul");
pref("browser.chromeURL","chrome://xulapp/content/browser.xul");
