function debug(aLogString) {
      var mConsoleService = Components.classes["@mozilla.org/consoleservice;1"]
                              .getService(Components.interfaces.nsIConsoleService)

      mConsoleService.logStringMessage("Open Special Browser XUL: " + aLogString + "\n");
    }
	
function handleParamaters()
{
	setURI();
	setProxtSettings();
}	
	
function setURI(){
	//window.innerWidth = screen.width; 
	//window.innerHeight = screen.height; 
	//window.screenX = 0; 
	//window.screenY = 0; 
	//alwaysLowered = false; 3
	
    if (window.arguments && window.arguments[0]){
      try {
        var cmdLine = window.arguments[0]
                          .QueryInterface(Components.interfaces.nsICommandLine);
        //for (var i = 0; i < cmdLine.length; ++i) {
	 
          //alert(cmdLine.getArgument(0));
		   //window.location=cmdLine.getArgument(i);
		   var browser = document.getElementById("browserid");
		   //alert(browser.src);
		   //browser.src = cmdLine.getArgument(i);
		   browser.loadURI(cmdLine.getArgument(0), null, "UTF-8");
		   document.title = cmdLine.getArgument(1);
        //}
      } catch(ex) {
        debug(window.arguments[0])
      }
    }
}

function setProxtSettings(){
	if (window.arguments && window.arguments[0]){
      try {
        var cmdLine = window.arguments[0]
                          .QueryInterface(Components.interfaces.nsICommandLine);
		var prefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefBranch);
		
		var proxyHost;
		var proxyPort;
		var socksVersion;
		var socksPort;
		var userName;
		var userPass;
		var proxyType;
		var proxyHttpsHost;
		var proxyHttpsPort;
		
		for (var i = 0; i < cmdLine.length; ++i) {
			var cmd = cmdLine.getArgument(i);
			//alert("cmd = " +  cmd);
			if (cmd.indexOf("proxyPort=") > -1)
			{
				proxyPort = cmd.substring(cmd.indexOf("=")+1);
				prefs.setIntPref("network.proxy.http_port", proxyPort);	
			}
			else if (cmd.indexOf("proxyHost=") > -1)
			{
				proxyHost = cmd.substring(cmd.indexOf("=")+1);
				prefs.setCharPref("network.proxy.http", proxyHost);	
			}
			else if (cmd.indexOf("proxyHttpsPort=") > -1)
			{
				proxyHttpsPort = cmd.substring(cmd.indexOf("=")+1);
				prefs.setIntPref("network.proxy.ssl_port", proxyHttpsPort);	
			}
			else if (cmd.indexOf("proxyHttpsHost=") > -1)
			{
				proxyHttpsHost = cmd.substring(cmd.indexOf("=")+1);
				prefs.setCharPref("network.proxy.ssl", proxyHttpsHost);	
			}
			else if (cmd.indexOf("socksVersion=") > -1)
			{
				socksVersion = cmd.substring(cmd.indexOf("=")+1);
				prefs.setIntPref("network.proxy.socks_version", socksVersion);					
			}
			else if (cmd.indexOf("userName=") > -1)
			{
				userName = cmd.substring(cmd.indexOf("=")+1);
			}
			else if (cmd.indexOf("userPass=") > -1)
			{
				userPass = cmd.substring(cmd.indexOf("=")+1);
			}
			else if (cmd.indexOf("socksPort=") > -1)
			{
				socksPort = cmd.substring(cmd.indexOf("=")+1);
				prefs.setIntPref("network.proxy.socks_port", socksPort);	
			}
			else if (cmd.indexOf("proxyType=") > -1)
			{
				//used when determining if this is http,socks or automatic
				proxyType = cmd.substring(cmd.indexOf("=")+1);
				prefs.setIntPref("network.proxy.type", proxyType);	
				//alert("network type = " + proxyType);
			}
		}
		
		if (proxyType == null)
		{
			if (proxyHost != null)
			{
				prefs.setIntPref("network.proxy.type", 1);
				//alert("network type = http");
			}
			else if (proxyHttpsHost != null)
			{
				prefs.setIntPref("network.proxy.type", 2);
			}			
		}
		
		if (proxyHost != null && proxyPort != null)
		{
			prefs.setCharPref("network.proxy.no_proxies_on", ",");		
		}	
		
      } catch(ex) {
        debug(window.arguments[0])
      }
    }
}

function   Minimize()    

  {    
	  window.innerWidth   =   100;    
	  window.innerHeight   =   100;    
	  window.screenX   =   screen.width;    
	  window.screenY   =   screen.height;    
	  alwaysLowered   =   true;    
  }    


  function   Maximize()    
  {    
	  window.innerWidth   =   screen.width;    
	  window.innerHeight   =   screen.height;    
	  window.screenX   =   0;    
	  window.screenY   =   0;    
	  alwaysLowered   =   false;    
  }     